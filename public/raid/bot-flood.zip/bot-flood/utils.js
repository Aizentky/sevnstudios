const names = [
"777zenttt",
"LeinMC",
"777qixn",
"777qxrr",
"JacobPh2773",
"ItsMaybeee",
"princemp4",
"scratt",
"KaizenHT5",
"ItzMezeIXD",
"Gabzyy",
"Eyman",
"Kervs",
"Imutheone",
"Sunbruhpogi",
"zackwasfoundd",
"komimiii",
"ElementalXD",
"idrewcvm",
"itzyoboikaii",
"KyleFragg",
"alyxz",
"H3poo0XD",
"24wrr_",
"Eren",
"Akaheng",
"yamiteee",
"Nero",
"walkzyfromwhish",
"CaligoMC",
"KyleSalem",
"qzvrr_",
"asianboybisaya_",
"asianboytagalogg",
"555tuna",
"JamesXD",
"Drdonuot",
"ZENMCXBERRY",
"ZcmTvv_",
"Kairoo",
"DOCTORKENN",
"javaobfuscator",
"SpeedSilver7578",
"BEBEK0",
];

function generateRandomName() {
    return names[Math.floor(Math.random() * names.length)];
}

module.exports = {
    generateRandomName
};