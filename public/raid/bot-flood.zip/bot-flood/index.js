const mineflayer = require('mineflayer');
const fs = require('fs');
const config = require('./config');
const { generateRandomName } = require('./utils');
const { SocksClient } = require('socks');

console.log(`[Launcher] Starting ${config.bots.count} bots...`);
console.log(`[Launcher] Target: ${config.server.host}:${config.server.port}`);

// Load proxies from proxies.txt
let proxies = [];
try {
    const proxyData = fs.readFileSync('./proxies.txt', 'utf8');
    proxies = proxyData
        .split('\n')
        .map(line => line.trim())
        .filter(line => line && !line.startsWith('#'));
    console.log(`[Proxy] Loaded ${proxies.length} proxies from proxies.txt`);
} catch (err) {
    console.log('[Proxy] No proxies.txt found or error reading it. Running without proxies.');
}

let proxyIndex = 0;

function getNextProxy() {
    if (proxies.length === 0) return null;
    const proxy = proxies[proxyIndex % proxies.length];
    proxyIndex++;
    return proxy;
}

function parseProxy(proxyStr) {
    const parts = proxyStr.split(':');
    if (parts.length < 2) return null;
   
    return {
        host: parts[0],
        port: parseInt(parts[1]),
        user: parts[2] || undefined,
        pass: parts[3] || undefined
    };
}

function createBot(botName, index) {
    const proxy = getNextProxy();
    let botOptions = {
        host: config.server.host,
        port: config.server.port,
        username: botName,
        version: config.server.version || false
    };

    // Proxy support
    if (proxy) {
        const proxyInfo = parseProxy(proxy);
        if (proxyInfo) {
            botOptions.connect = (client) => {
                SocksClient.createConnection({
                    proxy: {
                        host: proxyInfo.host,
                        port: proxyInfo.port,
                        type: 5,
                        userId: proxyInfo.user,
                        password: proxyInfo.pass
                    },
                    command: 'connect',
                    destination: {
                        host: config.server.host,
                        port: config.server.port
                    }
                }).then(info => {
                    client.setSocket(info.socket);
                    client.emit('connect');
                }).catch(err => {
                    console.log(`[${botName}] Proxy connection failed: ${err.message}`);
                });
            };
            console.log(`[${botName}] Using proxy → ${proxyInfo.host}:${proxyInfo.port}`);
        }
    }

    const bot = mineflayer.createBot(botOptions);

    bot.once('spawn', () => {
        console.log(`[${botName}] Spawned!`);

        // === auto registre ===
        setTimeout(() => {
            console.log(`[${botName}] Sending /bot registered!✅`);
            bot.chat('/register kyaaniethemc kyaaniethemc');
        }, 1500); // Small delay after spawn

        // === spam message ===
        setInterval(() => {
            bot.chat('777 x 67chris is here kill ur self owner synbinesmp on down###');
        }, 1000);

        // Optional: Keep your original auth/spam config if you still want to use it
        if (config.auth?.enabled && config.auth?.command) {
            setTimeout(() => {
                bot.chat(config.auth.command);
            }, config.auth.delay || 2000);
        }
    });

    bot.on('error', (err) => {
        console.log(`[${botName}] Error:`, err.message);
    });

    bot.on('kicked', (reason) => {
        console.log(`[${botName}] Kicked:`, reason);
    });

    bot.on('end', () => {
        console.log(`[${botName}] Disconnected`);
    });
}

function start() {
    let currentBot = 0;
    const interval = setInterval(() => {
        if (currentBot >= config.bots.count) {
            clearInterval(interval);
            console.log('[Launcher] All bots launched!');
            return;
        }

        let botName;
        if (config.naming?.type === 'random') {
            botName = generateRandomName(config.naming.randomLength || 15);
        } else {
            botName = `${config.naming?.baseName || 'Bot'}${currentBot + 1}`;
        }

        createBot(botName, currentBot);
        currentBot++;
    }, config.bots?.joinDelay || 1200);
}

start();