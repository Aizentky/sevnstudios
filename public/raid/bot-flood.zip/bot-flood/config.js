module.exports = {
    // Server Connection Details
    server: {
        host: 'proxy-ip',     // e.g. from your proxy list
        host: "143.14.88.10",
        port: 6009,
        version: "1.21.4" 
    },

    // Bot Configuration
    bots: {
        count: 200, // Number of bots to spawn
        joinDelay: 110, // Delay between each bot joining (ms)
    },

    // Naming Strategy
    naming: {
        type: "random", // "sequential" (Name1, Name2) or "random" (Xy8kL9)
        baseName: "StressBot", // Used for sequential naming
        randomLength: 13 // Length of random names
    },

    // Authentication / On Join Command
    auth: {
        enabled: false,
        // Command to execute after joining. 
        // useful for /register <password> or /login <password>
        command: "/register kyaaniethemcrack kyaaniethemcrack",
        delay: 1000 // Time to wait after spawning before sending command (ms)
    },

    // Spam Configuration
    spam: {
        enabled: true,
        interval: 3000, // Time between messages (ms)
        messages: [
            
        ]
    }
};
